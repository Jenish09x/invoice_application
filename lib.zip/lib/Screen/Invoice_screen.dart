import 'package:flutter/material.dart';

import '../Utils/global_class.dart';

class InvoiceMaker extends StatefulWidget {
  const InvoiceMaker({super.key});

  @override
  State<InvoiceMaker> createState() => _InvoiceMakerState();
}

class _InvoiceMakerState extends State<InvoiceMaker> {
  TextEditingController txtProductName = TextEditingController();
  TextEditingController txtProductNo = TextEditingController();
  TextEditingController txtGST = TextEditingController();
  TextEditingController txtDiscount = TextEditingController();
  TextEditingController txtQa = TextEditingController();
  TextEditingController txtprice = TextEditingController();
  double total = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          centerTitle: true,
          title: Text(" Invoice Maker ",
              style: TextStyle(fontSize: 25, color: Colors.white)),
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                textTile(txtProductName,'Product Name'),
                const SizedBox(height: 10),
                textTile(txtProductNo,'Product No.'),
                const SizedBox(height: 10),
                textTile(txtGST,'GST No.'),
                const SizedBox(height: 10),
                textTile(txtDiscount,'Discount'),
                const SizedBox(height: 10),
                Row(
                  children: [
                    SizedBox(width: 190, child: textTile(txtQa,"Quantity")),
                    const SizedBox(width: 10),
                    SizedBox(width: 190, child: textTile(txtprice,"Price")),
                  ],
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                    onPressed: () {
                      Global g1 = Global();
                      g1.InvoiceList.addAll([
                        txtProductName.text,
                        txtProductNo.text,
                        txtGST.text,
                        txtDiscount.text,
                        txtQa.text,
                        txtprice.text,
                      ]);
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("${g1.InvoiceList}")));
                      setState(() {
                        total = double.parse(txtprice.text) *
                            double.parse(txtQa.text);
                      });
                    },
                    child: Text("NEXT")),
                const SizedBox(height: 10),
                Text(
                  "Total Payment : ${total}",
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  TextField textTile(TextEditingController controller,String hint,) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.emailAddress,
      decoration: InputDecoration(
        label: Text(
          hint,
          style: TextStyle(
            color: Colors.grey.shade400,
          ),
        ),
      ),
    );
  }
}