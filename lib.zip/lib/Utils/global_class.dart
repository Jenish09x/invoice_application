class Global{
  List InvoiceList=[];
}